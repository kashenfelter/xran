# tufte

[![Build Status](https://travis-ci.org/rstudio/tufte.svg)](https://travis-ci.org/rstudio/tufte)
[![Downloads from the RStudio CRAN mirror](http://cranlogs.r-pkg.org/badges/grand-total/tufte)](https://cran.rstudio.org/package=tufte)

This R package provides a few R Markdown output formats that use the Tufte style. See http://rstudio.github.io/tufte for a comprehensive example. To install the development version of this package from Github, you may use `devtools::install_github('rstudio/tufte')`. You can also install it from [CRAN](https://cran.rstudio.org/package=tufte) (`install.packages('tufte')`).
